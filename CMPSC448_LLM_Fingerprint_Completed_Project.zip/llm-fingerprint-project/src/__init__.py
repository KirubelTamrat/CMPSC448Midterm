"""LLM authorship attribution project."""
